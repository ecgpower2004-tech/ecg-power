# ECG Power 技术规范文档

## 1. 组件清单

### shadcn/ui 内置组件

| 组件名 | 用途 | 安装命令 |
|--------|------|----------|
| Button | 所有按钮交互 | `npx shadcn add button` |
| Card | 产品卡片、新闻卡片 | `npx shadcn add card` |
| Input | 表单输入框 | `npx shadcn add input` |
| Select | 下拉选择器 | `npx shadcn add select` |
| Checkbox | 多选框 | `npx shadcn add checkbox` |
| Dialog | 弹窗、模态框 | `npx shadcn add dialog` |
| Tabs | 标签切换 | `npx shadcn add tabs` |
| Accordion | 折叠面板 | `npx shadcn add accordion` |
| Badge | 标签徽章 | `npx shadcn add badge` |
| Slider | 滑块选择器 | `npx shadcn add slider` |
| Sheet | 侧边抽屉 | `npx shadcn add sheet` |
| ScrollArea | 滚动区域 | `npx shadcn add scroll-area` |
| Separator | 分隔线 | `npx shadcn add separator` |
| Skeleton | 加载骨架 | `npx shadcn add skeleton` |
| Toast | 消息提示 | `npx shadcn add toast` |
| DropdownMenu | 下拉菜单 | `npx shadcn add dropdown-menu` |

### 自定义组件

| 组件名 | 用途 | 位置 |
|--------|------|------|
| Navbar | 固定导航栏 | `components/Navbar.tsx` |
| Footer | 页脚 | `components/Footer.tsx` |
| HeroCarousel | Hero轮播 | `sections/HeroCarousel.tsx` |
| WorldMap | 全球热力图 | `sections/WorldMap.tsx` |
| ProductCard | 产品卡片 | `components/ProductCard.tsx` |
| ProductFilter | 产品筛选器 | `components/ProductFilter.tsx` |
| CustomForm | 定制表单 | `sections/CustomForm.tsx` |
| AIRecommend | AI推荐结果 | `sections/AIRecommend.tsx` |
| Timeline | 发展时间线 | `components/Timeline.tsx` |
| TeamCard | 团队卡片 | `components/TeamCard.tsx` |
| NewsCard | 新闻卡片 | `components/NewsCard.tsx` |
| ContactForm | 联系表单 | `sections/ContactForm.tsx` |
| LanguageSwitcher | 语言切换器 | `components/LanguageSwitcher.tsx` |
| AnimatedCounter | 动画计数器 | `components/AnimatedCounter.tsx` |
| ScrollReveal | 滚动显示动画 | `components/ScrollReveal.tsx` |

### 自定义Hooks

| Hook名 | 用途 | 位置 |
|--------|------|------|
| useScrollAnimation | 滚动触发动画 | `hooks/useScrollAnimation.ts` |
| useGeolocation | 地理定位检测 | `hooks/useGeolocation.ts` |
| useLanguage | 多语言切换 | `hooks/useLanguage.ts` |
| useInView | 元素可见性检测 | `hooks/useInView.ts` |

---

## 2. 动画实现方案

### 动画库选择

| 库名 | 版本 | 用途 |
|------|------|------|
| Framer Motion | ^11.0 | React组件动画、手势交互 |
| GSAP | ^3.12 | 复杂时间线动画、ScrollTrigger |
| @gsap/react | ^2.1 | GSAP React集成 |

### 动画实现表

| 动画效果 | 库 | 实现方式 | 复杂度 |
|----------|-----|----------|--------|
| 页面加载序列 | Framer Motion | AnimatePresence + motion.div | Medium |
| 导航栏滚动效果 | Framer Motion | useScroll + useTransform | Low |
| Hero轮播切换 | Framer Motion | AnimatePresence + variants | Medium |
| 滚动触发淡入 | GSAP ScrollTrigger | scrollTrigger + fromTo | Medium |
| 数字计数动画 | Framer Motion | useSpring + animate | Low |
| 产品卡片悬停 | Framer Motion | whileHover + scale | Low |
| 按钮交互效果 | Framer Motion | whileHover + whileTap | Low |
| 时间线动画 | GSAP ScrollTrigger | stagger + scrollTrigger | High |
| 表单步骤切换 | Framer Motion | AnimatePresence + layout | Medium |
| AI推荐结果淡入 | Framer Motion | staggerChildren | Medium |
| 地图热力点脉冲 | CSS Animation | @keyframes pulse | Low |
| 图标旋转动画 | Framer Motion | animate + rotate | Low |

### 动画参数规范

```typescript
// 通用动画配置
export const animationConfig = {
  // 缓动函数
  easing: {
    default: [0.4, 0, 0.2, 1], // ease-out
    bounce: [0.68, -0.55, 0.265, 1.55],
    smooth: [0.25, 0.1, 0.25, 1],
  },
  
  // 时长
  duration: {
    fast: 0.2,
    normal: 0.4,
    slow: 0.6,
    slower: 0.8,
  },
  
  // 滚动触发
  scrollTrigger: {
    threshold: 0.2,
    rootMargin: '-50px',
  },
  
  // 交错动画
  stagger: {
    fast: 0.05,
    normal: 0.1,
    slow: 0.15,
  },
};

// 动画变体
export const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: [0.4, 0, 0.2, 1] }
  },
};

export const fadeInLeft = {
  hidden: { opacity: 0, x: -40 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { duration: 0.6, ease: [0.4, 0, 0.2, 1] }
  },
};

export const scaleIn = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: { duration: 0.5, ease: [0.4, 0, 0.2, 1] }
  },
};

export const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};
```

---

## 3. 项目文件结构

```
/mnt/okcomputer/output/app/
├── public/
│   ├── images/
│   │   ├── hero/
│   │   ├── products/
│   │   ├── team/
│   │   ├── news/
│   │   └── about/
│   ├── videos/
│   └── locales/
│       ├── en.json
│       ├── es.json
│       └── fr.json
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn组件
│   │   ├── Navbar.tsx
│   │   ├── Footer.tsx
│   │   ├── ProductCard.tsx
│   │   ├── NewsCard.tsx
│   │   ├── TeamCard.tsx
│   │   ├── Timeline.tsx
│   │   ├── LanguageSwitcher.tsx
│   │   ├── AnimatedCounter.tsx
│   │   ├── ScrollReveal.tsx
│   │   └── WorldMap.tsx
│   ├── sections/
│   │   ├── home/
│   │   │   ├── HeroCarousel.tsx
│   │   │   ├── GlobalPresence.tsx
│   │   │   ├── ProductCategories.tsx
│   │   │   ├── IndustryApplications.tsx
│   │   │   └── VideoSection.tsx
│   │   ├── products/
│   │   │   ├── ProductGrid.tsx
│   │   │   ├── ProductFilter.tsx
│   │   │   └── ProductDetail.tsx
│   │   ├── customized/
│   │   │   ├── CustomForm.tsx
│   │   │   └── AIRecommend.tsx
│   │   ├── about/
│   │   │   ├── CompanyIntro.tsx
│   │   │   ├── Timeline.tsx
│   │   │   ├── TeamSection.tsx
│   │   │   └── Certifications.tsx
│   │   ├── news/
│   │   │   ├── NewsList.tsx
│   │   │   └── NewsFilter.tsx
│   │   └── contact/
│   │       ├── ContactForm.tsx
│   │       ├── OfficeMap.tsx
│   │       └── ContactInfo.tsx
│   ├── hooks/
│   │   ├── useScrollAnimation.ts
│   │   ├── useGeolocation.ts
│   │   ├── useLanguage.ts
│   │   └── useInView.ts
│   ├── lib/
│   │   ├── utils.ts
│   │   ├── animations.ts
│   │   ├── i18n.ts
│   │   └── data.ts
│   ├── types/
│   │   └── index.ts
│   ├── pages/
│   │   ├── Home.tsx
│   │   ├── Products.tsx
│   │   ├── Customized.tsx
│   │   ├── About.tsx
│   │   ├── News.tsx
│   │   └── Contact.tsx
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── index.html
├── tailwind.config.js
├── vite.config.ts
├── tsconfig.json
└── package.json
```

---

## 4. 依赖清单

### 核心依赖

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.22.0",
    "framer-motion": "^11.0.0",
    "gsap": "^3.12.5",
    "@gsap/react": "^2.1.0",
    "i18next": "^23.8.0",
    "react-i18next": "^14.0.0",
    "i18next-browser-languagedetector": "^7.2.0",
    "lucide-react": "^0.323.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.2.0",
    "@radix-ui/react-*": "latest"
  }
}
```

### 开发依赖

```json
{
  "devDependencies": {
    "@types/react": "^18.2.55",
    "@types/react-dom": "^18.2.19",
    "@types/node": "^20.11.0",
    "@vitejs/plugin-react": "^4.2.1",
    "typescript": "^5.3.3",
    "vite": "^5.1.0",
    "tailwindcss": "^3.4.1",
    "autoprefixer": "^10.4.17",
    "postcss": "^8.4.35"
  }
}
```

---

## 5. 路由配置

```typescript
// App.tsx 路由结构
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/products/:id" element={<ProductDetail />} />
        <Route path="/customized" element={<Customized />} />
        <Route path="/about" element={<About />} />
        <Route path="/news" element={<News />} />
        <Route path="/news/:slug" element={<NewsDetail />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}
```

---

## 6. 样式配置

### Tailwind 扩展配置

```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        brand: {
          orange: '#FF6B00',
          'orange-dark': '#E56000',
          navy: '#0A1628',
          yellow: '#FFD700',
          gray: '#4A4A4A',
        },
      },
      fontFamily: {
        sans: ['Helvetica Neue', 'Arial', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
};
```

---

## 7. 性能优化策略

### 图片优化
- 使用WebP格式
- 懒加载 (loading="lazy")
- 响应式图片 (srcset)
- 占位符模糊效果

### 代码优化
- 路由懒加载 (React.lazy)
- 组件代码分割
- Tree-shaking
- 压缩和混淆

### 动画优化
- 使用transform和opacity
- will-change属性
- 减少重绘重排
- prefers-reduced-motion支持

---

## 8. SEO配置

### Schema结构化数据

```typescript
// Product Schema
const productSchema = {
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "ECG Power Cummins 500kW Diesel Generator",
  "image": "...",
  "description": "...",
  "brand": {
    "@type": "Brand",
    "name": "ECG Power"
  },
  "offers": {
    "@type": "Offer",
    "url": "...",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock"
  }
};

// Organization Schema
const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "ECG Power",
  "url": "https://ecgpower.com",
  "logo": "...",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+86-189-8928-4087",
    "contactType": "sales",
    "availableLanguage": ["English", "Spanish", "French"]
  }
};
```

### Meta标签模板

```typescript
// 每个页面的SEO配置
interface SEOConfig {
  title: string;
  description: string;
  keywords: string[];
  ogImage: string;
  canonical: string;
}

// Home页示例
const homeSEO: SEOConfig = {
  title: "Industrial Diesel Generator Manufacturer | ECG Power",
  description: "Reliable diesel generators for Americas, Europe & Africa. 5000+ units deployed across 120+ countries. Cummins, Deutz, Kubota powered.",
  keywords: ["diesel generator", "industrial generator", "Cummins generator", "power solutions"],
  ogImage: "/images/og-home.jpg",
  canonical: "https://ecgpower.com"
};
```
