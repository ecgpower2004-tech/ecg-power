import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Filter, 
  ChevronDown, 
  Zap, 
  Settings, 
  ArrowRight,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

// Product Data
const products = [
  {
    id: 1,
    name: 'Cummins 500kW Diesel Generator',
    brand: 'cummins',
    power: 500,
    powerRange: '200-500',
    image: '/images/products/cummins-500kw.jpg',
    engine: 'Cummins KTA19-G4',
    alternator: 'Stamford HCI544C',
    fuelTank: '8-10 hours',
    noise: '< 85 dB',
    applications: ['construction', 'mining', 'factory'],
    price: 'Contact for Quote',
    features: ['Water-cooled', 'Turbocharged', 'Electronic Governor'],
  },
  {
    id: 2,
    name: 'Deutz 200kW Silent Generator',
    brand: 'deutz',
    power: 200,
    powerRange: '100-200',
    image: '/images/products/deutz-200kw.jpg',
    engine: 'Deutz BF6M1015C',
    alternator: 'Leroy Somer TAL040C',
    fuelTank: '8-10 hours',
    noise: '< 75 dB',
    applications: ['factory', 'emergency', 'construction'],
    price: 'Contact for Quote',
    features: ['Silent Canopy', 'Fuel Efficient', 'Low Maintenance'],
  },
  {
    id: 3,
    name: 'Kubota 30kW Portable Generator',
    brand: 'kubota',
    power: 30,
    powerRange: '8-50',
    image: '/images/products/kubota-30kw.jpg',
    engine: 'Kubota V3300',
    alternator: 'Kubota SK330',
    fuelTank: '6-8 hours',
    noise: '< 70 dB',
    applications: ['agriculture', 'emergency', 'construction'],
    price: 'Contact for Quote',
    features: ['Compact Design', 'Easy Transport', 'Reliable Start'],
  },
  {
    id: 4,
    name: 'Cummins 1000kW Industrial Generator',
    brand: 'cummins',
    power: 1000,
    powerRange: '500-1000',
    image: '/images/products/container-generator.jpg',
    engine: 'Cummins KTA38-G5',
    alternator: 'Stamford PI734C',
    fuelTank: '12-16 hours',
    noise: '< 90 dB',
    applications: ['mining', 'factory', 'datacenter'],
    price: 'Contact for Quote',
    features: ['Containerized', 'High Output', 'Parallel Capable'],
  },
  {
    id: 5,
    name: 'Deutz 350kW Silent Generator',
    brand: 'deutz',
    power: 350,
    powerRange: '200-500',
    image: '/images/products/silent-generator.jpg',
    engine: 'Deutz BF8M1015CP',
    alternator: 'Leroy Somer TAL044G',
    fuelTank: '10-12 hours',
    noise: '< 78 dB',
    applications: ['construction', 'factory', 'emergency'],
    price: 'Contact for Quote',
    features: ['Super Silent', 'ATS Ready', 'Remote Monitoring'],
  },
  {
    id: 6,
    name: 'Kubota 50kW Agricultural Generator',
    brand: 'kubota',
    power: 50,
    powerRange: '8-50',
    image: '/images/products/kubota-30kw.jpg',
    engine: 'Kubota V3800',
    alternator: 'Kubota SK380',
    fuelTank: '8-10 hours',
    noise: '< 72 dB',
    applications: ['agriculture', 'construction'],
    price: 'Contact for Quote',
    features: ['Durable Build', 'Easy Service', 'Weather Resistant'],
  },
];

// Filter Options
const brands = [
  { id: 'cummins', name: 'Cummins', count: 2 },
  { id: 'deutz', name: 'Deutz', count: 2 },
  { id: 'kubota', name: 'Kubota', count: 2 },
];

const powerRanges = [
  { id: '8-50', name: '8-50 kW', count: 2 },
  { id: '50-200', name: '50-200 kW', count: 2 },
  { id: '200-500', name: '200-500 kW', count: 2 },
  { id: '500-1000', name: '500-1000 kW', count: 1 },
];

const applications = [
  { id: 'construction', name: 'Construction', count: 4 },
  { id: 'mining', name: 'Mining', count: 2 },
  { id: 'agriculture', name: 'Agriculture', count: 2 },
  { id: 'factory', name: 'Factory', count: 3 },
  { id: 'emergency', name: 'Emergency Power', count: 3 },
  { id: 'datacenter', name: 'Data Center', count: 1 },
];

function ProductCard({ product, onClick }: { product: typeof products[0]; onClick: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-xl overflow-hidden border border-gray-100 card-hover group"
    >
      <div className="aspect-[4/3] overflow-hidden relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-brand-orange text-white text-xs font-semibold px-3 py-1 rounded-full">
            {product.power}kW
          </span>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-lg font-bold text-brand-navy mb-2">{product.name}</h3>
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-gray-600">
            <Settings className="w-4 h-4 mr-2 text-brand-orange" />
            {product.engine}
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Zap className="w-4 h-4 mr-2 text-brand-orange" />
            {product.alternator}
          </div>
        </div>
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <span className="text-brand-orange font-semibold">{product.price}</span>
          <Button 
            onClick={onClick}
            className="text-sm bg-brand-navy hover:bg-brand-orange transition-colors"
          >
            View Details
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

function ProductDetailDialog({ product, isOpen, onClose }: { 
  product: typeof products[0] | null; 
  isOpen: boolean; 
  onClose: () => void;
}) {
  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-brand-navy">
            {product.name}
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-4">
          <div className="aspect-[4/3] rounded-xl overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-brand-navy mb-4">Technical Specifications</h3>
            <div className="space-y-3">
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Rated Power</span>
                <span className="font-semibold">{product.power} kW / {Math.round(product.power * 1.25)} kVA</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Engine Model</span>
                <span className="font-semibold">{product.engine}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Alternator</span>
                <span className="font-semibold">{product.alternator}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Fuel Tank Capacity</span>
                <span className="font-semibold">{product.fuelTank}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Noise Level</span>
                <span className="font-semibold">{product.noise}</span>
              </div>
            </div>
            
            <h3 className="text-lg font-semibold text-brand-navy mt-6 mb-4">Key Features</h3>
            <div className="flex flex-wrap gap-2">
              {product.features.map((feature, index) => (
                <span
                  key={index}
                  className="bg-brand-orange/10 text-brand-orange text-sm px-3 py-1 rounded-full"
                >
                  {feature}
                </span>
              ))}
            </div>

            <div className="mt-8 flex gap-4">
              <Link to="/customized" className="flex-1">
                <Button className="w-full btn-primary">
                  Request Quote
                </Button>
              </Link>
              <Link to="/contact" className="flex-1">
                <Button className="w-full btn-secondary">
                  Contact Sales
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function Products() {
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedPowerRanges, setSelectedPowerRanges] = useState<string[]>([]);
  const [selectedApplications, setSelectedApplications] = useState<string[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  const toggleFilter = (filter: string, selected: string[], setSelected: (v: string[]) => void) => {
    if (selected.includes(filter)) {
      setSelected(selected.filter(f => f !== filter));
    } else {
      setSelected([...selected, filter]);
    }
  };

  const filteredProducts = products.filter(product => {
    const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(product.brand);
    const powerMatch = selectedPowerRanges.length === 0 || selectedPowerRanges.includes(product.powerRange);
    const appMatch = selectedApplications.length === 0 || 
      product.applications.some(app => selectedApplications.includes(app));
    return brandMatch && powerMatch && appMatch;
  });

  const clearFilters = () => {
    setSelectedBrands([]);
    setSelectedPowerRanges([]);
    setSelectedApplications([]);
  };

  const activeFiltersCount = selectedBrands.length + selectedPowerRanges.length + selectedApplications.length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-brand-navy py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Diesel Generator <span className="text-brand-orange">Product Range</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Industrial-grade generators from 8kW to 2000kW, powered by world-renowned engine manufacturers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Products Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters - Desktop */}
            <div className="hidden lg:block w-64 flex-shrink-0">
              <div className="bg-white rounded-xl p-6 sticky top-24">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-bold text-brand-navy flex items-center gap-2">
                    <Filter className="w-5 h-5" />
                    Filters
                  </h3>
                  {activeFiltersCount > 0 && (
                    <button
                      onClick={clearFilters}
                      className="text-sm text-brand-orange hover:underline"
                    >
                      Clear all
                    </button>
                  )}
                </div>

                <Accordion type="multiple" defaultValue={['brand', 'power', 'application']}>
                  <AccordionItem value="brand">
                    <AccordionTrigger className="text-sm font-semibold">Engine Brand</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-3">
                        {brands.map(brand => (
                          <label key={brand.id} className="flex items-center gap-3 cursor-pointer">
                            <Checkbox
                              checked={selectedBrands.includes(brand.id)}
                              onCheckedChange={() => toggleFilter(brand.id, selectedBrands, setSelectedBrands)}
                            />
                            <span className="text-sm flex-1">{brand.name}</span>
                            <span className="text-xs text-gray-400">({brand.count})</span>
                          </label>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="power">
                    <AccordionTrigger className="text-sm font-semibold">Power Range</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-3">
                        {powerRanges.map(range => (
                          <label key={range.id} className="flex items-center gap-3 cursor-pointer">
                            <Checkbox
                              checked={selectedPowerRanges.includes(range.id)}
                              onCheckedChange={() => toggleFilter(range.id, selectedPowerRanges, setSelectedPowerRanges)}
                            />
                            <span className="text-sm flex-1">{range.name}</span>
                            <span className="text-xs text-gray-400">({range.count})</span>
                          </label>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="application">
                    <AccordionTrigger className="text-sm font-semibold">Application</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-3">
                        {applications.map(app => (
                          <label key={app.id} className="flex items-center gap-3 cursor-pointer">
                            <Checkbox
                              checked={selectedApplications.includes(app.id)}
                              onCheckedChange={() => toggleFilter(app.id, selectedApplications, setSelectedApplications)}
                            />
                            <span className="text-sm flex-1">{app.name}</span>
                            <span className="text-xs text-gray-400">({app.count})</span>
                          </label>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            </div>

            {/* Mobile Filter Button */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
                className="w-full bg-white rounded-lg p-4 flex items-center justify-between"
              >
                <span className="font-semibold flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Filters
                  {activeFiltersCount > 0 && (
                    <span className="bg-brand-orange text-white text-xs px-2 py-0.5 rounded-full">
                      {activeFiltersCount}
                    </span>
                  )}
                </span>
                <ChevronDown className={`w-5 h-5 transition-transform ${isMobileFilterOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {isMobileFilterOpen && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="bg-white rounded-lg mt-2 p-4"
                >
                  {/* Mobile filters content */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Engine Brand</h4>
                      <div className="flex flex-wrap gap-2">
                        {brands.map(brand => (
                          <button
                            key={brand.id}
                            onClick={() => toggleFilter(brand.id, selectedBrands, setSelectedBrands)}
                            className={`px-3 py-1 rounded-full text-sm ${
                              selectedBrands.includes(brand.id)
                                ? 'bg-brand-orange text-white'
                                : 'bg-gray-100 text-gray-700'
                            }`}
                          >
                            {brand.name}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Power Range</h4>
                      <div className="flex flex-wrap gap-2">
                        {powerRanges.map(range => (
                          <button
                            key={range.id}
                            onClick={() => toggleFilter(range.id, selectedPowerRanges, setSelectedPowerRanges)}
                            className={`px-3 py-1 rounded-full text-sm ${
                              selectedPowerRanges.includes(range.id)
                                ? 'bg-brand-orange text-white'
                                : 'bg-gray-100 text-gray-700'
                            }`}
                          >
                            {range.name}
                          </button>
                        ))}
                      </div>
                    </div>
                    {activeFiltersCount > 0 && (
                      <button
                        onClick={clearFilters}
                        className="text-brand-orange text-sm hover:underline"
                      >
                        Clear all filters
                      </button>
                    )}
                  </div>
                </motion.div>
              )}
            </div>

            {/* Product Grid */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-6">
                <p className="text-gray-600">
                  Showing <span className="font-semibold text-brand-navy">{filteredProducts.length}</span> products
                </p>
                {activeFiltersCount > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">Active filters:</span>
                    <div className="flex gap-2">
                      {selectedBrands.map(brand => (
                        <span key={brand} className="bg-brand-orange/10 text-brand-orange text-xs px-2 py-1 rounded-full flex items-center gap-1">
                          {brands.find(b => b.id === brand)?.name}
                          <X className="w-3 h-3 cursor-pointer" onClick={() => toggleFilter(brand, selectedBrands, setSelectedBrands)} />
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onClick={() => setSelectedProduct(product)}
                  />
                ))}
              </div>

              {filteredProducts.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                    <Filter className="w-10 h-10 text-gray-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-brand-navy mb-2">No products found</h3>
                  <p className="text-gray-600 mb-4">Try adjusting your filters to see more results.</p>
                  <Button onClick={clearFilters} className="btn-primary">
                    Clear Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Product Detail Dialog */}
      <ProductDetailDialog
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
}
