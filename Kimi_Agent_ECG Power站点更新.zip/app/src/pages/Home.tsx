import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  ArrowRight,
  HardHat,
  Pickaxe,
  Tractor,
  Zap,
  Globe,
  Users,
  Settings,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';

// Hero Slides Data
const heroSlides = [
  {
    image: '/images/hero/hero-1.jpg',
    title: 'Powering the World with Reliable Diesel Generators',
    subtitle: 'Industrial-grade power solutions for construction, mining, and emergency backup across 120+ countries',
  },
  {
    image: '/images/hero/hero-2.jpg',
    title: 'Mining Operations Trust ECG Power',
    subtitle: 'High-capacity generators designed for the most demanding industrial environments',
  },
  {
    image: '/images/hero/hero-3.jpg',
    title: 'Energy Solutions for Remote Locations',
    subtitle: 'From African power stations to emergency deployments worldwide',
  },
];

// Stats Data
const stats = [
  { value: 5000, suffix: '+', label: 'Units Deployed', icon: Settings },
  { value: 120, suffix: '+', label: 'Countries Served', icon: Globe },
  { value: 14, suffix: '+', label: 'Years Experience', icon: Users },
];

// Product Categories
const productCategories = [
  {
    name: 'Cummins Series',
    power: '50-2000kW',
    image: '/images/products/cummins-500kw.jpg',
    description: 'American engineering excellence for heavy-duty applications',
  },
  {
    name: 'Deutz Series',
    power: '30-800kW',
    image: '/images/products/deutz-200kw.jpg',
    description: 'German precision engineering with superior fuel efficiency',
  },
  {
    name: 'Kubota Series',
    power: '8-50kW',
    image: '/images/products/kubota-30kw.jpg',
    description: 'Compact and reliable solutions for small-scale operations',
  },
];

// Industry Applications
const industries = [
  { name: 'Construction', icon: HardHat, description: 'Powering job sites worldwide' },
  { name: 'Mining', icon: Pickaxe, description: 'Heavy-duty solutions for extraction' },
  { name: 'Agriculture', icon: Tractor, description: 'Reliable power for farms' },
  { name: 'Emergency Power', icon: Zap, description: '24/7 backup when you need it' },
];

// Global Presence Data
const globalStats = [
  { region: 'Americas', clients: 1800, countries: 'North & South America' },
  { region: 'Europe', clients: 1500, countries: 'EU & UK' },
  { region: 'Africa', clients: 1200, countries: 'Sub-Saharan & North Africa' },
  { region: 'Asia-Pacific', clients: 500, countries: 'Asia & Oceania' },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    
    return () => clearInterval(timer);
  }, [value]);
  
  return <span>{count.toLocaleString()}{suffix}</span>;
}

function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);

  return (
    <section className="relative h-screen min-h-[600px] overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0"
        >
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${heroSlides[currentSlide].image})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-navy/90 via-brand-navy/70 to-transparent" />
        </motion.div>
      </AnimatePresence>

      <div className="relative h-full container-custom flex items-center">
        <div className="max-w-2xl text-white">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                {heroSlides[currentSlide].title}
              </h1>
              <p className="text-lg md:text-xl text-gray-300 mb-8">
                {heroSlides[currentSlide].subtitle}
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/products">
                  <Button className="btn-primary text-base">
                    Explore Products
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/customized">
                  <Button className="btn-secondary text-base">
                    Get Custom Quote
                  </Button>
                </Link>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-colors"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-colors"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {heroSlides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              currentSlide === index ? 'bg-brand-orange w-8' : 'bg-white/50'
            }`}
          />
        ))}
      </div>
    </section>
  );
}

function StatsSection() {
  return (
    <section className="bg-brand-navy py-12">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-lg bg-brand-orange/20 flex items-center justify-center">
                <stat.icon className="w-7 h-7 text-brand-orange" />
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold text-white">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-gray-400">{stat.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function GlobalPresence() {
  return (
    <section className="section-padding bg-brand-navy industrial-pattern">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Global Presence, <span className="text-brand-orange">Local Support</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            With clients across 120+ countries, we provide reliable power solutions 
            and 24/7 technical support worldwide.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {globalStats.map((region, index) => (
            <motion.div
              key={region.region}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-brand-orange/50 transition-colors"
            >
              <div className="text-brand-orange text-sm font-medium mb-2">{region.region}</div>
              <div className="text-3xl font-bold text-white mb-1">
                <AnimatedCounter value={region.clients} suffix="+" />
              </div>
              <div className="text-gray-400 text-sm">Clients</div>
              <div className="mt-4 pt-4 border-t border-white/10 text-gray-500 text-sm">
                {region.countries}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProductCategories() {
  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-brand-navy mb-4">
            Power Solutions by <span className="text-brand-orange">Engine Brand</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Choose from world-renowned engine manufacturers, each offering unique 
            advantages for your specific power requirements.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {productCategories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to="/products" className="group block">
                <div className="bg-gray-50 rounded-2xl overflow-hidden card-hover">
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-bold text-brand-navy">{category.name}</h3>
                      <span className="text-brand-orange font-semibold">{category.power}</span>
                    </div>
                    <p className="text-gray-600 text-sm">{category.description}</p>
                    <div className="mt-4 flex items-center text-brand-orange font-medium">
                      View Products
                      <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function IndustryApplications() {
  return (
    <section className="section-padding bg-gray-50">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-brand-navy mb-4">
            Trusted Across <span className="text-brand-orange">Industries</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our generators power critical operations in diverse sectors, 
            from construction sites to emergency response.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {industries.map((industry, index) => (
            <motion.div
              key={industry.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl p-6 text-center card-hover border border-gray-100"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-brand-orange/10 flex items-center justify-center">
                <industry.icon className="w-8 h-8 text-brand-orange" />
              </div>
              <h3 className="text-lg font-bold text-brand-navy mb-2">{industry.name}</h3>
              <p className="text-gray-500 text-sm">{industry.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function VideoSection() {
  return (
    <section className="section-padding bg-brand-navy">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              See How We Build <span className="text-brand-orange">Reliability</span>
            </h2>
            <p className="text-gray-400 mb-8 leading-relaxed">
              Take a virtual tour of our state-of-the-art manufacturing facilities in 
              Chengdu and Fuzhou. From precision engineering to rigorous quality testing, 
              witness how we craft generators that power the world.
            </p>
            <ul className="space-y-4 mb-8">
              {[
                'ISO 9001:2015 Certified Manufacturing',
                'Advanced Robotics & Automation',
                '100% Load Testing Before Shipment',
                'Global Distribution Network',
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-3 text-gray-300">
                  <CheckCircle className="w-5 h-5 text-brand-orange flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
            <Link to="/about">
              <Button className="btn-primary">
                Learn More About Us
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden aspect-video">
              <img
                src="/images/about/factory.jpg"
                alt="ECG Power Manufacturing Facility"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <button className="w-20 h-20 rounded-full bg-brand-orange flex items-center justify-center hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-white ml-1" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-r from-brand-orange to-brand-yellow">
      <div className="container-custom text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Power Your Project?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Get a customized quote within 24 hours. Our team of experts is ready 
            to help you find the perfect power solution.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/customized">
              <Button className="bg-white text-brand-orange hover:bg-gray-100 px-8 py-4 text-base font-semibold">
                Request Quote
              </Button>
            </Link>
            <Link to="/contact">
              <Button className="bg-transparent border-2 border-white text-white hover:bg-white/10 px-8 py-4 text-base font-semibold">
                Contact Sales
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function Home() {
  return (
    <div>
      <HeroCarousel />
      <StatsSection />
      <GlobalPresence />
      <ProductCategories />
      <IndustryApplications />
      <VideoSection />
      <CTASection />
    </div>
  );
}
