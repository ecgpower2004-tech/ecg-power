import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Play, 
  Award, 
  Globe, 
  CheckCircle,
  ArrowRight,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';

// Timeline Data
const timeline = [
  {
    year: '2010',
    title: 'ECG Power Founded',
    description: 'Established in Chengdu, China with a vision to provide reliable power solutions globally.',
    details: 'Started with a small team of 10 engineers and technicians, focusing on diesel generator assembly and testing.',
  },
  {
    year: '2015',
    title: 'Expansion to Fujian',
    description: 'Opened second manufacturing facility in Fuzhou to meet growing demand.',
    details: 'New 50,000 sqm facility with advanced robotics and automated testing lines. Production capacity increased by 300%.',
  },
  {
    year: '2018',
    title: 'First Major Africa Export',
    description: 'Successfully delivered 500 units to power infrastructure projects across Africa.',
    details: 'Partnership with major construction companies in Nigeria and Kenya. Established local service centers.',
  },
  {
    year: '2020',
    title: 'ISO 9001 Certification',
    description: 'Achieved international quality management certification.',
    details: 'Rigorous audit process covering design, manufacturing, testing, and after-sales service. Quality standards aligned with international norms.',
  },
  {
    year: '2022',
    title: 'Africa Mega Project',
    description: 'Delivered 1000kW generators for major mining operations in South Africa.',
    details: 'Custom-designed containerized power solution with parallel capability. 99.8% uptime achieved over 12 months.',
  },
  {
    year: '2023',
    title: 'Global Distribution Network',
    description: 'Established offices in New York, Miami, Frankfurt, and Johannesburg.',
    details: '24/7 technical support coverage across all time zones. Local inventory for faster delivery and service.',
  },
];

// Team Data
const team = [
  {
    name: 'Zhang Wei',
    role: 'Chief Executive Officer',
    image: '/images/team/ceo.jpg',
    bio: '20+ years in power generation industry. Former senior engineer at Cummins China.',
  },
  {
    name: 'Li Ming',
    role: 'Chief Technology Officer',
    image: '/images/team/cto.jpg',
    bio: 'PhD in Mechanical Engineering. Expert in diesel engine optimization and emissions control.',
  },
  {
    name: 'Wang Hua',
    role: 'Sales Director',
    image: '/images/team/ceo.jpg',
    bio: '15+ years in international trade. Led expansion into 50+ countries.',
  },
  {
    name: 'Chen Jing',
    role: 'Quality Manager',
    image: '/images/team/cto.jpg',
    bio: 'ISO 9001 lead auditor. Ensures every unit meets our rigorous quality standards.',
  },
];

// Certifications
const certifications = [
  {
    name: 'ISO 9001:2015',
    description: 'Quality Management System',
    icon: Award,
  },
  {
    name: 'CE Certification',
    description: 'European Conformity',
    icon: CheckCircle,
  },
  {
    name: 'EPA Compliance',
    description: 'US Environmental Standards',
    icon: Globe,
  },
  {
    name: 'CCS Certified',
    description: 'China Classification Society',
    icon: Award,
  },
];

function TimelineItem({ 
  item, 
  index, 
  isExpanded, 
  onToggle 
}: { 
  item: typeof timeline[0]; 
  index: number; 
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const isLeft = index % 2 === 0;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className={`relative flex items-start gap-8 ${isLeft ? 'flex-row' : 'flex-row-reverse'}`}
    >
      {/* Content */}
      <div className={`flex-1 ${isLeft ? 'text-right' : 'text-left'}`}>
        <div 
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow"
          onClick={onToggle}
        >
          <div className={`flex items-center gap-2 mb-2 ${isLeft ? 'justify-end' : 'justify-start'}`}>
            <span className="text-brand-orange font-bold text-lg">{item.year}</span>
            {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </div>
          <h3 className="text-xl font-bold text-brand-navy mb-2">{item.title}</h3>
          <p className="text-gray-600">{item.description}</p>
          
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-4 pt-4 border-t border-gray-100"
            >
              <p className="text-gray-500 text-sm">{item.details}</p>
            </motion.div>
          )}
        </div>
      </div>
      
      {/* Center Dot */}
      <div className="relative flex-shrink-0">
        <div className="w-4 h-4 rounded-full bg-brand-orange border-4 border-white shadow-md" />
        {index < timeline.length - 1 && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-0.5 h-24 bg-gray-200" />
        )}
      </div>
      
      {/* Empty Space */}
      <div className="flex-1" />
    </motion.div>
  );
}

function TeamCard({ member }: { member: typeof team[0] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 card-hover"
    >
      <div className="aspect-[3/4] overflow-hidden">
        <img
          src={member.image}
          alt={member.name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <h3 className="text-lg font-bold text-brand-navy">{member.name}</h3>
        <p className="text-brand-orange text-sm font-medium mb-3">{member.role}</p>
        <p className="text-gray-600 text-sm">{member.bio}</p>
      </div>
    </motion.div>
  );
}

export function About() {
  const [expandedTimeline, setExpandedTimeline] = useState<number | null>(null);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="bg-brand-navy py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Building Power Solutions <span className="text-brand-orange">Since 2010</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-3xl mx-auto">
              From a small workshop in Chengdu to a global power solutions provider, 
              our journey has been defined by innovation, quality, and customer trust.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Video Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-brand-navy mb-6">
                Our Mission & Vision
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  At ECG Power, we believe that reliable power is the foundation of progress. 
                  Our mission is to provide industrial-grade diesel generators that keep businesses 
                  running, communities thriving, and critical infrastructure operational.
                </p>
                <p>
                  With manufacturing facilities in Chengdu and Fuzhou, we combine Chinese 
                  manufacturing excellence with world-renowned engine technology from Cummins, 
                  Deutz, and Kubota to deliver products that meet the highest international standards.
                </p>
                <p>
                  Our vision is to be the most trusted power solutions partner for businesses 
                  across construction, mining, agriculture, and emergency services worldwide.
                </p>
              </div>
              
              <div className="grid grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-brand-orange">5000+</div>
                  <div className="text-sm text-gray-500">Units Deployed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-brand-orange">120+</div>
                  <div className="text-sm text-gray-500">Countries</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-brand-orange">14+</div>
                  <div className="text-sm text-gray-500">Years Experience</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden aspect-video">
                <img
                  src="/images/about/factory.jpg"
                  alt="ECG Power Manufacturing"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <button 
                    className="w-20 h-20 rounded-full bg-brand-orange flex items-center justify-center hover:scale-110 transition-transform"
                  >
                    <Play className="w-8 h-8 text-white ml-1" />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-brand-navy mb-4">
              Our <span className="text-brand-orange">Journey</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              From humble beginnings to global reach, explore the milestones that 
              have shaped ECG Power into what it is today.
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto space-y-8">
            {timeline.map((item, index) => (
              <TimelineItem
                key={item.year}
                item={item}
                index={index}
                isExpanded={expandedTimeline === index}
                onToggle={() => setExpandedTimeline(expandedTimeline === index ? null : index)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-brand-navy mb-4">
              Meet Our <span className="text-brand-orange">Leadership</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our experienced team brings together expertise in engineering, 
              manufacturing, and international business.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member) => (
              <TeamCard key={member.name} member={member} />
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="section-padding bg-brand-navy">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Certifications & <span className="text-brand-orange">Standards</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our commitment to quality is validated by internationally recognized certifications.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 text-center hover:border-brand-orange/50 transition-colors"
              >
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-brand-orange/20 flex items-center justify-center">
                  <cert.icon className="w-8 h-8 text-brand-orange" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{cert.name}</h3>
                <p className="text-gray-400 text-sm">{cert.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-brand-orange rounded-2xl p-12 text-center"
          >
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Work With Us?
            </h2>
            <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
              Let's discuss how ECG Power can provide the reliable power solutions 
              your business needs.
            </p>
            <Link to="/contact">
              <Button className="bg-white text-brand-orange hover:bg-gray-100 px-8 py-4 text-base font-semibold">
                Contact Our Team
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
