import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  ArrowRight, 
  Tag, 
  Linkedin, 
  Twitter, 
  Facebook,
  Share2,
  Clock,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// News Categories
const categories = [
  { id: 'all', name: 'All News' },
  { id: 'technical', name: 'Technical Updates' },
  { id: 'cases', name: 'Customer Cases' },
  { id: 'industry', name: 'Industry Trends' },
];

// News Data
const newsArticles = [
  {
    id: 1,
    title: 'ECG Power Delivers 1000kW Generators to Brazilian Mining Project',
    excerpt: 'Successfully deployed high-altitude compatible generators for one of South America\'s largest mining operations, ensuring uninterrupted power supply in challenging terrain.',
    image: '/images/news/brazil-mining.jpg',
    category: 'cases',
    date: '2024-01-15',
    author: 'ECG Power Team',
    readTime: '5 min read',
    featured: true,
  },
  {
    id: 2,
    title: 'European Diesel Generator Market Report 2024',
    excerpt: 'Analysis of market trends, growth opportunities, and regulatory changes affecting the power generation industry across Europe.',
    image: '/images/hero/hero-2.jpg',
    category: 'industry',
    date: '2024-01-10',
    author: 'Market Research Team',
    readTime: '8 min read',
    featured: false,
  },
  {
    id: 3,
    title: 'New Cummins-Powered Series Launch: Higher Efficiency, Lower Emissions',
    excerpt: 'Introducing our latest high-efficiency generator series featuring advanced engine technology and improved fuel economy.',
    image: '/images/products/cummins-500kw.jpg',
    category: 'technical',
    date: '2024-01-05',
    author: 'Engineering Team',
    readTime: '4 min read',
    featured: false,
  },
  {
    id: 4,
    title: 'Emergency Power Solutions for African Healthcare Facilities',
    excerpt: 'How ECG Power generators are helping hospitals and clinics maintain critical operations during power outages.',
    image: '/images/hero/hero-3.jpg',
    category: 'cases',
    date: '2023-12-28',
    author: 'Africa Operations Team',
    readTime: '6 min read',
    featured: false,
  },
  {
    id: 5,
    title: 'Understanding Diesel Generator Maintenance: Best Practices',
    excerpt: 'Essential maintenance tips to maximize the lifespan and performance of your diesel generator investment.',
    image: '/images/products/deutz-200kw.jpg',
    category: 'technical',
    date: '2023-12-20',
    author: 'Technical Support Team',
    readTime: '7 min read',
    featured: false,
  },
  {
    id: 6,
    title: 'The Future of Hybrid Power: Integrating Diesel and Renewable Energy',
    excerpt: 'Exploring the emerging trend of hybrid power systems that combine diesel generators with solar and battery storage.',
    image: '/images/about/factory.jpg',
    category: 'industry',
    date: '2023-12-15',
    author: 'Innovation Team',
    readTime: '6 min read',
    featured: false,
  },
];

function NewsCard({ article }: { article: typeof newsArticles[0] }) {
  const categoryName = categories.find(c => c.id === article.category)?.name || article.category;
  
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-xl overflow-hidden border border-gray-100 card-hover group"
    >
      <div className="aspect-[16/9] overflow-hidden relative">
        <img
          src={article.image}
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4">
          <Badge className="bg-brand-orange text-white">
            {categoryName}
          </Badge>
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
          <span className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            {new Date(article.date).toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'short', 
              day: 'numeric' 
            })}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {article.readTime}
          </span>
        </div>
        <h3 className="text-xl font-bold text-brand-navy mb-3 line-clamp-2 group-hover:text-brand-orange transition-colors">
          {article.title}
        </h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {article.excerpt}
        </p>
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <span className="text-sm text-gray-500 flex items-center gap-1">
            <User className="w-4 h-4" />
            {article.author}
          </span>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <Share2 className="w-4 h-4 text-gray-500" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Linkedin className="w-4 h-4 mr-2" />
                  Share on LinkedIn
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Twitter className="w-4 h-4 mr-2" />
                  Share on Twitter
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Facebook className="w-4 h-4 mr-2" />
                  Share on Facebook
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <button className="text-brand-orange font-medium text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
              Read More
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );
}

function FeaturedArticle({ article }: { article: typeof newsArticles[0] }) {
  const categoryName = categories.find(c => c.id === article.category)?.name || article.category;
  
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-lg"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2">
        <div className="aspect-[16/9] lg:aspect-auto overflow-hidden">
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="p-8 lg:p-12 flex flex-col justify-center">
          <div className="flex items-center gap-4 mb-4">
            <Badge className="bg-brand-orange text-white">
              Featured
            </Badge>
            <Badge variant="outline">
              {categoryName}
            </Badge>
          </div>
          <h2 className="text-2xl lg:text-3xl font-bold text-brand-navy mb-4">
            {article.title}
          </h2>
          <p className="text-gray-600 mb-6 leading-relaxed">
            {article.excerpt}
          </p>
          <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {new Date(article.date).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {article.readTime}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Button className="btn-primary">
              Read Full Article
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <Share2 className="w-5 h-5 text-gray-500" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>
                  <Linkedin className="w-4 h-4 mr-2" />
                  Share on LinkedIn
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Twitter className="w-4 h-4 mr-2" />
                  Share on Twitter
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Facebook className="w-4 h-4 mr-2" />
                  Share on Facebook
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </motion.article>
  );
}

export function News() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredArticles = selectedCategory === 'all'
    ? newsArticles
    : newsArticles.filter(article => article.category === selectedCategory);

  const featuredArticle = newsArticles.find(article => article.featured);
  const regularArticles = filteredArticles.filter(article => !article.featured || selectedCategory !== 'all');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-brand-navy py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Latest News & <span className="text-brand-orange">Insights</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Stay updated with the latest developments in diesel generator technology, 
              customer success stories, and industry trends.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-white border-b border-gray-100">
        <div className="container-custom">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedCategory === category.id
                    ? 'bg-brand-orange text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {selectedCategory === 'all' && featuredArticle && (
        <section className="section-padding bg-gray-50">
          <div className="container-custom">
            <FeaturedArticle article={featuredArticle} />
          </div>
        </section>
      )}

      {/* News Grid */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-brand-navy">
              {selectedCategory === 'all' ? 'All Articles' : categories.find(c => c.id === selectedCategory)?.name}
            </h2>
            <span className="text-gray-500 text-sm">
              Showing {regularArticles.length} articles
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {regularArticles.map((article) => (
              <NewsCard key={article.id} article={article} />
            ))}
          </div>

          {regularArticles.length === 0 && (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                <Tag className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-brand-navy mb-2">No articles found</h3>
              <p className="text-gray-600">Try selecting a different category.</p>
            </div>
          )}

          {/* Load More */}
          {regularArticles.length > 0 && (
            <div className="text-center mt-12">
              <Button variant="outline" className="px-8">
                Load More Articles
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="section-padding bg-brand-navy">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-2xl mx-auto"
          >
            <h2 className="text-3xl font-bold text-white mb-4">
              Subscribe to Our Newsletter
            </h2>
            <p className="text-gray-400 mb-8">
              Get the latest news, product updates, and industry insights delivered 
              directly to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-gray-500 focus:outline-none focus:border-brand-orange"
              />
              <Button className="btn-primary whitespace-nowrap">
                Subscribe
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
