import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, 
  Check, 
  RotateCw,
  Loader2,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

// Application options
const applications = [
  { id: 'farm', name: 'Farm', icon: '🚜' },
  { id: 'factory', name: 'Factory', icon: '🏭' },
  { id: 'mining', name: 'Mining', icon: '⛏️' },
  { id: 'emergency', name: 'Emergency', icon: '🚨' },
  { id: 'datacenter', name: 'Data Center', icon: '💻' },
  { id: 'construction', name: 'Construction', icon: '🏗️' },
];

// Currency options
const currencies = [
  { code: 'USD', symbol: '$', rate: 1 },
  { code: 'EUR', symbol: '€', rate: 0.92 },
];

// Mock AI recommendations
const mockRecommendations = [
  {
    id: 1,
    name: 'Cummins 300kW Silent Generator',
    image: '/images/products/cummins-500kw.jpg',
    power: 300,
    efficiency: '92%',
    noise: '< 78 dB',
    priceUSD: 45000,
    matchScore: 98,
    type: 'Best Match',
    features: ['Silent Canopy', 'ATS Ready', 'Remote Monitoring'],
  },
  {
    id: 2,
    name: 'Deutz 250kW Industrial Generator',
    image: '/images/products/deutz-200kw.jpg',
    power: 250,
    efficiency: '90%',
    noise: '< 82 dB',
    priceUSD: 38000,
    matchScore: 92,
    type: 'Budget Friendly',
    features: ['Fuel Efficient', 'Low Maintenance', 'Compact Design'],
  },
  {
    id: 3,
    name: 'Cummins 400kW Premium Generator',
    image: '/images/products/container-generator.jpg',
    power: 400,
    efficiency: '94%',
    noise: '< 75 dB',
    priceUSD: 62000,
    matchScore: 88,
    type: 'Premium',
    features: ['Containerized', 'Parallel Capable', '5-Year Warranty'],
  },
];

function RecommendationCard({ 
  product, 
  currency 
}: { 
  product: typeof mockRecommendations[0]; 
  currency: typeof currencies[0];
}) {
  const price = Math.round(product.priceUSD * currency.rate);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl overflow-hidden border-2 border-gray-100 hover:border-brand-orange transition-colors"
    >
      <div className="relative">
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute top-4 left-4">
          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
            product.type === 'Best Match' ? 'bg-brand-orange text-white' :
            product.type === 'Budget Friendly' ? 'bg-green-500 text-white' :
            'bg-brand-navy text-white'
          }`}>
            {product.type}
          </span>
        </div>
        <div className="absolute top-4 right-4">
          <div className="bg-white rounded-full px-3 py-1 flex items-center gap-1">
            <span className="text-brand-orange font-bold">{product.matchScore}%</span>
            <span className="text-xs text-gray-500">Match</span>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-lg font-bold text-brand-navy mb-4">{product.name}</h3>
        
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="text-brand-orange font-bold">{product.power}kW</div>
            <div className="text-xs text-gray-500">Power</div>
          </div>
          <div className="text-center">
            <div className="text-brand-orange font-bold">{product.efficiency}</div>
            <div className="text-xs text-gray-500">Efficiency</div>
          </div>
          <div className="text-center">
            <div className="text-brand-orange font-bold">{product.noise}</div>
            <div className="text-xs text-gray-500">Noise</div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {product.features.map((feature, index) => (
            <span
              key={index}
              className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
            >
              {feature}
            </span>
          ))}
        </div>
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div>
            <span className="text-2xl font-bold text-brand-navy">
              {currency.symbol}{price.toLocaleString()}
            </span>
            <span className="text-gray-500 text-sm ml-1">est.</span>
          </div>
          <Link to="/contact">
            <Button className="btn-primary text-sm">
              Inquire Now
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

export function Customized() {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  
  // Form state
  const [powerRange, setPowerRange] = useState([200]);
  const [selectedApps, setSelectedApps] = useState<string[]>([]);
  const [budget, setBudget] = useState('');
  const [currency, setCurrency] = useState(currencies[0]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');

  const toggleApp = (appId: string) => {
    if (selectedApps.includes(appId)) {
      setSelectedApps(selectedApps.filter(id => id !== appId));
    } else {
      setSelectedApps([...selectedApps, appId]);
    }
  };

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    setIsLoading(true);
    // Simulate AI processing
    setTimeout(() => {
      setIsLoading(false);
      setShowResults(true);
      setShowSuccessDialog(true);
    }, 2000);
  };

  const canProceed = () => {
    if (step === 1) return true;
    if (step === 2) return selectedApps.length > 0;
    if (step === 3) return name && email && country;
    return false;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-brand-navy py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Get Your <span className="text-brand-orange">Custom Power Solution</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Our AI-powered recommendation engine analyzes your requirements 
              to find the perfect generator for your needs.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Form Section */}
      <section className="section-padding">
        <div className="container-custom">
          {!showResults ? (
            <div className="max-w-3xl mx-auto">
              {/* Progress */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  {['Power Requirements', 'Application', 'Contact Info'].map((label, index) => (
                    <div key={label} className="flex items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                        step > index + 1 ? 'bg-brand-orange text-white' :
                        step === index + 1 ? 'bg-brand-orange text-white' :
                        'bg-gray-200 text-gray-500'
                      }`}>
                        {step > index + 1 ? <Check className="w-5 h-5" /> : index + 1}
                      </div>
                      <span className={`ml-2 text-sm hidden sm:block ${
                        step >= index + 1 ? 'text-brand-navy font-medium' : 'text-gray-400'
                      }`}>
                        {label}
                      </span>
                      {index < 2 && (
                        <div className={`w-12 sm:w-24 h-1 mx-2 sm:mx-4 ${
                          step > index + 1 ? 'bg-brand-orange' : 'bg-gray-200'
                        }`} />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Form Card */}
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-2xl shadow-lg p-8"
              >
                {step === 1 && (
                  <div>
                    <h2 className="text-2xl font-bold text-brand-navy mb-2">
                      What's your power requirement?
                    </h2>
                    <p className="text-gray-600 mb-8">
                      Select the power range that best fits your needs.
                    </p>
                    
                    <div className="mb-8">
                      <div className="flex items-center justify-between mb-4">
                        <Label className="text-lg font-semibold">Power Output</Label>
                        <span className="text-3xl font-bold text-brand-orange">
                          {powerRange[0]} kW
                        </span>
                      </div>
                      <Slider
                        value={powerRange}
                        onValueChange={setPowerRange}
                        min={50}
                        max={1000}
                        step={50}
                        className="mb-4"
                      />
                      <div className="flex justify-between text-sm text-gray-500">
                        <span>50 kW</span>
                        <span>1000 kW</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      {[100, 200, 500, 1000].map((value) => (
                        <button
                          key={value}
                          onClick={() => setPowerRange([value])}
                          className={`p-3 rounded-lg border-2 transition-colors ${
                            powerRange[0] === value
                              ? 'border-brand-orange bg-brand-orange/5 text-brand-orange'
                              : 'border-gray-200 hover:border-brand-orange/50'
                          }`}
                        >
                          {value} kW
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div>
                    <h2 className="text-2xl font-bold text-brand-navy mb-2">
                      What will you use it for?
                    </h2>
                    <p className="text-gray-600 mb-8">
                      Select all applicable applications.
                    </p>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      {applications.map((app) => (
                        <button
                          key={app.id}
                          onClick={() => toggleApp(app.id)}
                          className={`relative p-4 rounded-xl border-2 transition-all text-center ${
                            selectedApps.includes(app.id)
                              ? 'border-brand-orange bg-brand-orange/5'
                              : 'border-gray-200 hover:border-brand-orange/50'
                          }`}
                        >
                          <div className="text-3xl mb-2">{app.icon}</div>
                          <div className={`text-sm font-medium ${
                            selectedApps.includes(app.id) ? 'text-brand-orange' : 'text-gray-700'
                          }`}>
                            {app.name}
                          </div>
                          {selectedApps.includes(app.id) && (
                            <div className="absolute top-2 right-2">
                              <Check className="w-4 h-4 text-brand-orange" />
                            </div>
                          )}
                        </button>
                      ))}
                    </div>

                    <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                      <Label className="text-sm font-semibold mb-2 block">Budget Range (Optional)</Label>
                      <div className="flex gap-4">
                        <Select
                          value={currency.code}
                          onValueChange={(code) => setCurrency(currencies.find(c => c.code === code) || currencies[0])}
                        >
                          <SelectTrigger className="w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {currencies.map((c) => (
                              <SelectItem key={c.code} value={c.code}>
                                {c.code} ({c.symbol})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          type="number"
                          placeholder="Enter your budget"
                          value={budget}
                          onChange={(e) => setBudget(e.target.value)}
                          className="flex-1"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div>
                    <h2 className="text-2xl font-bold text-brand-navy mb-2">
                      How can we reach you?
                    </h2>
                    <p className="text-gray-600 mb-8">
                      We'll send your customized recommendations to this contact.
                    </p>
                    
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="name">Full Name *</Label>
                        <Input
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="John Smith"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="john@example.com"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input
                          id="phone"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+1 234 567 890"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="country">Country *</Label>
                        <Select value={country} onValueChange={setCountry}>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Select your country" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="us">United States</SelectItem>
                            <SelectItem value="uk">United Kingdom</SelectItem>
                            <SelectItem value="de">Germany</SelectItem>
                            <SelectItem value="fr">France</SelectItem>
                            <SelectItem value="br">Brazil</SelectItem>
                            <SelectItem value="za">South Africa</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Navigation */}
                <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
                  {step > 1 ? (
                    <Button
                      variant="outline"
                      onClick={() => setStep(step - 1)}
                      className="px-6"
                    >
                      Back
                    </Button>
                  ) : (
                    <div />
                  )}
                  <Button
                    onClick={handleNext}
                    disabled={!canProceed() || isLoading}
                    className="btn-primary px-8"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : step === 3 ? (
                      <>
                        Get Recommendations
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </>
                    ) : (
                      <>
                        Continue
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </motion.div>
            </div>
          ) : (
            /* Results Section */
            <div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl font-bold text-brand-navy mb-4">
                  Recommended Generators for You
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Based on your requirements ({powerRange[0]}kW power range, 
                  {selectedApps.length > 0 && ` ${selectedApps.length} applications`}), 
                  our AI has selected these optimal solutions.
                </p>
                <button
                  onClick={() => {
                    setShowResults(false);
                    setStep(1);
                  }}
                  className="mt-4 text-brand-orange hover:underline inline-flex items-center gap-2"
                >
                  <RotateCw className="w-4 h-4" />
                  Start Over
                </button>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {mockRecommendations.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <RecommendationCard product={product} currency={currency} />
                  </motion.div>
                ))}
              </div>

              <div className="text-center mt-12">
                <p className="text-gray-600 mb-4">
                  Not sure which one to choose? Our experts can help.
                </p>
                <Link to="/contact">
                  <Button className="btn-primary">
                    Talk to an Expert
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Success Dialog */}
      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <span className="text-2xl font-bold text-brand-navy">Request Received!</span>
            </DialogTitle>
          </DialogHeader>
          <div className="text-center">
            <p className="text-gray-600 mb-6">
              Thank you for your inquiry. Our team will review your requirements 
              and get back to you within 24 hours.
            </p>
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <div className="text-sm text-gray-500 mb-1">Response Time</div>
              <div className="font-semibold text-brand-navy">
                {country === 'de' || country === 'fr' || country === 'uk' 
                  ? 'European customers: 30 minutes' 
                  : 'Within 24 hours'}
              </div>
            </div>
            <Button 
              onClick={() => setShowSuccessDialog(false)}
              className="btn-primary w-full"
            >
              View Recommendations
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
