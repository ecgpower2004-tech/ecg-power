import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Send, 
  CheckCircle,
  Loader2,
  Globe,
  Linkedin,
  Facebook,
  Twitter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

// Office Locations
const offices = [
  {
    region: 'Americas',
    locations: [
      { city: 'New York', address: '350 Fifth Avenue, Suite 2500, NY 10118', phone: '+1 212-555-0100' },
      { city: 'Miami', address: '801 Brickell Avenue, Suite 900, FL 33131', phone: '+1 305-555-0200' },
    ],
  },
  {
    region: 'Europe',
    locations: [
      { city: 'Frankfurt', address: 'Mainzer Landstraße 50, 60325 Frankfurt', phone: '+49 69-555-0300' },
    ],
  },
  {
    region: 'Africa',
    locations: [
      { city: 'Johannesburg', address: '1 Maude Street, Sandton 2196', phone: '+27 11-555-0400' },
    ],
  },
  {
    region: 'Asia-Pacific',
    locations: [
      { city: 'Chengdu', address: 'No. 88 Tianfu Avenue, High-Tech Zone', phone: '+86 28-555-0500' },
      { city: 'Fuzhou', address: 'No. 123 Jiangbin Avenue, Mawei District', phone: '+86 591-555-0600' },
    ],
  },
];

// Countries for dropdown
const countries = [
  'United States',
  'Canada',
  'Brazil',
  'Mexico',
  'United Kingdom',
  'Germany',
  'France',
  'Italy',
  'Spain',
  'Netherlands',
  'South Africa',
  'Nigeria',
  'Kenya',
  'Ghana',
  'China',
  'India',
  'Australia',
  'Japan',
  'Other',
];

export function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    country: '',
    company: '',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setShowSuccessDialog(true);
    setFormData({
      name: '',
      email: '',
      phone: '',
      country: '',
      company: '',
      message: '',
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-brand-navy py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Get in <span className="text-brand-orange">Touch</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Have a question or need a quote? Our team is ready to help. 
              24/7 technical support available for all customers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-white rounded-2xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-brand-navy mb-2">
                  Send Us a Message
                </h2>
                <p className="text-gray-600 mb-8">
                  Fill out the form below and we'll get back to you within 24 hours.
                </p>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="John Smith"
                        required
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="john@example.com"
                        required
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="+1 234 567 890"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="country">Country *</Label>
                      <Select
                        value={formData.country}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, country: value }))}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select your country" />
                        </SelectTrigger>
                        <SelectContent>
                          {countries.map((country) => (
                            <SelectItem key={country} value={country}>
                              {country}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="company">Company Name</Label>
                    <Input
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      placeholder="Your company name"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Tell us about your power requirements..."
                      required
                      className="mt-1 min-h-[150px]"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full btn-primary py-4"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5 mr-2" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </motion.div>

            {/* Contact Info & Map */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              {/* Quick Contact */}
              <div className="bg-white rounded-2xl shadow-lg p-8">
                <h3 className="text-xl font-bold text-brand-navy mb-6">
                  Quick Contact
                </h3>
                <div className="space-y-4">
                  <a
                    href="mailto:info@ecgpower.com"
                    className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-brand-orange/5 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-full bg-brand-orange/10 flex items-center justify-center group-hover:bg-brand-orange/20 transition-colors">
                      <Mail className="w-5 h-5 text-brand-orange" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Email Us</div>
                      <div className="font-semibold text-brand-navy">info@ecgpower.com</div>
                    </div>
                  </a>
                  
                  <a
                    href="tel:+8618989284087"
                    className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-brand-orange/5 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-full bg-brand-orange/10 flex items-center justify-center group-hover:bg-brand-orange/20 transition-colors">
                      <Phone className="w-5 h-5 text-brand-orange" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Call Us</div>
                      <div className="font-semibold text-brand-navy">+86 189 8928 4087</div>
                    </div>
                  </a>
                  
                  <div className="flex items-center gap-4 p-4 rounded-xl bg-gray-50">
                    <div className="w-12 h-12 rounded-full bg-brand-orange/10 flex items-center justify-center">
                      <Clock className="w-5 h-5 text-brand-orange" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Support Hours</div>
                      <div className="font-semibold text-brand-navy">24/7 Technical Support</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Global Offices */}
              <div className="bg-white rounded-2xl shadow-lg p-8">
                <h3 className="text-xl font-bold text-brand-navy mb-6">
                  Global Offices
                </h3>
                <div className="space-y-6">
                  {offices.map((office) => (
                    <div key={office.region}>
                      <div className="flex items-center gap-2 mb-3">
                        <Globe className="w-4 h-4 text-brand-orange" />
                        <span className="font-semibold text-brand-navy">{office.region}</span>
                      </div>
                      <div className="space-y-2 ml-6">
                        {office.locations.map((location) => (
                          <div key={location.city} className="text-sm">
                            <span className="font-medium text-gray-700">{location.city}:</span>
                            <span className="text-gray-500 ml-1">{location.address}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Social Links */}
              <div className="bg-brand-navy rounded-2xl p-8 text-white">
                <h3 className="text-xl font-bold mb-4">Follow Us</h3>
                <p className="text-gray-400 mb-6">
                  Stay connected for the latest updates and industry insights.
                </p>
                <div className="flex gap-4">
                  <a
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-brand-orange transition-colors"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-brand-orange transition-colors"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                  <a
                    href="https://twitter.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-brand-orange transition-colors"
                  >
                    <Twitter className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="h-[400px] bg-gray-200 relative">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3433.548156875!2d104.0665!3d30.5728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x36efc5c0c3b5c1c1%3A0x7c8c5c5c5c5c5c5c!2sChengdu%2C%20Sichuan%2C%20China!5e0!3m2!1sen!2sus!4v1609459200000!5m2!1sen!2sus"
          width="100%"
          height="100%"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="ECG Power Location"
        />
        <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-brand-orange rounded-lg flex items-center justify-center">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-semibold text-brand-navy">ECG Power Headquarters</div>
              <div className="text-sm text-gray-500">Chengdu, China</div>
            </div>
          </div>
        </div>
      </section>

      {/* Success Dialog */}
      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <span className="text-2xl font-bold text-brand-navy">Message Sent!</span>
            </DialogTitle>
          </DialogHeader>
          <div className="text-center">
            <p className="text-gray-600 mb-6">
              Thank you for reaching out. We've received your message and will 
              respond as soon as possible.
            </p>
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <div className="text-sm text-gray-500 mb-1">Expected Response Time</div>
              <div className="font-semibold text-brand-navy">
                {formData.country && ['Germany', 'France', 'United Kingdom', 'Netherlands', 'Italy', 'Spain'].includes(formData.country)
                  ? 'European customers: 30 minutes'
                  : 'Within 24 hours'}
              </div>
            </div>
            <Button 
              onClick={() => setShowSuccessDialog(false)}
              className="btn-primary w-full"
            >
              Got it, thanks!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
