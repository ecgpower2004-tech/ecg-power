import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Globe, ChevronDown, Phone, Mail } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'Products', path: '/products' },
  { name: 'Customized', path: '/customized' },
  { name: 'About Us', path: '/about' },
  { name: 'News', path: '/news' },
  { name: 'Contact', path: '/contact' },
];

const languages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentLang, setCurrentLang] = useState('en');
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Top Bar */}
      <div className="bg-brand-navy text-white py-2 px-4 text-sm">
        <div className="container-custom flex justify-between items-center">
          <div className="flex items-center gap-6">
            <a href="tel:+8618989284087" className="flex items-center gap-2 hover:text-brand-orange transition-colors">
              <Phone className="w-4 h-4" />
              <span>+86 189 8928 4087</span>
            </a>
            <a href="mailto:info@ecgpower.com" className="flex items-center gap-2 hover:text-brand-orange transition-colors hidden sm:flex">
              <Mail className="w-4 h-4" />
              <span>info@ecgpower.com</span>
            </a>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-gray-400 hidden sm:inline">Chengdu & Fuzhou, China</span>
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1 hover:text-brand-orange transition-colors">
                <Globe className="w-4 h-4" />
                <span className="uppercase">{currentLang}</span>
                <ChevronDown className="w-3 h-3" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    onClick={() => setCurrentLang(lang.code)}
                    className={currentLang === lang.code ? 'bg-brand-orange/10 text-brand-orange' : ''}
                  >
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-lg'
            : 'bg-white'
        }`}
      >
        <div className="container-custom">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" onClick={scrollToTop} className="flex items-center gap-3">
              <div className="w-12 h-12 bg-brand-navy rounded-lg flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-8 h-8">
                  <path
                    d="M20 2L4 10v20l16 8 16-8V10L20 2z"
                    fill="#0A1628"
                  />
                  <path
                    d="M20 6L8 12v16l12 6 12-6V12L20 6z"
                    fill="#FF6B00"
                  />
                  <path
                    d="M18 14l-4 8h4l-2 8 10-10h-5l3-6h-6z"
                    fill="#0A1628"
                  />
                </svg>
              </div>
              <div>
                <span className="text-xl font-bold text-brand-navy">ECG</span>
                <span className="text-xl font-bold text-brand-orange"> Power</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={scrollToTop}
                  className={`relative text-sm font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'text-brand-orange'
                      : 'text-brand-navy hover:text-brand-orange'
                  }`}
                >
                  {link.name}
                  {location.pathname === link.path && (
                    <motion.div
                      layoutId="nav-underline"
                      className="absolute -bottom-1 left-0 right-0 h-0.5 bg-brand-orange"
                    />
                  )}
                </Link>
              ))}
            </nav>

            {/* CTA Button */}
            <div className="hidden lg:block">
              <Link
                to="/customized"
                className="btn-primary text-sm"
              >
                Get Quote
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-brand-navy"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-white border-t"
            >
              <nav className="container-custom py-4 flex flex-col gap-2">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      scrollToTop();
                    }}
                    className={`py-3 px-4 rounded-lg transition-colors ${
                      location.pathname === link.path
                        ? 'bg-brand-orange/10 text-brand-orange'
                        : 'text-brand-navy hover:bg-gray-100'
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <Link
                  to="/customized"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="btn-primary text-center mt-4"
                >
                  Get Quote
                </Link>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>
    </>
  );
}
